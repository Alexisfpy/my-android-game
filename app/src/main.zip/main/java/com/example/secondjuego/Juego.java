package com.example.secondjuego;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.example.secondjuego.Pantallas.Pantalla;
import com.example.secondjuego.Pantallas.PantallaAjustes;
import com.example.secondjuego.Pantallas.PantallaAyuda;
import com.example.secondjuego.Pantallas.PantallaCreditos;
import com.example.secondjuego.Pantallas.PantallaJuego;
import com.example.secondjuego.Pantallas.PantallaMenu;
import com.example.secondjuego.Pantallas.PantallaGameOver;
import com.example.secondjuego.Pantallas.PantallaRecords;


import java.util.ArrayList;

public class Juego extends SurfaceView implements SurfaceHolder.Callback {
    private SurfaceHolder surfaceHolder; // Interfaz abstracta para manejar la superficie de dibujado
    private Context context; // Contexto de la aplicación
    static int anchoPantalla; // Ancho de la pantalla, su valor se actualiza en el método surfaceChanged
    static int  altoPantalla=1; // Alto de la pantalla, su valor se actualiza en el método surfaceChanged
    private Hilo hilo; // Hilo encargado de dibujar y actualizar la física
    private boolean funcionando = false; // Control del hilo
    Heroe heroe;
    Bitmap bitmapHeroe;
    int cont =0;
    int choqueCont=-4;

    //fondo
    private Bitmap bitmapFondo; // Imagen de fondo
    private  Fondo[]fondo = new Fondo[2];
    private boolean esTitulo=true;
    private boolean move;

    Rect rectHeroe;
    Bitmap bitmapEnemig1b;
    Bitmap bitmapEnemig2b;
    Bitmap bitmapEnemigRun;
    Bitmap bitmapEnemigV;
    Bitmap bitmapHeroeGhost;

    //Vibracion
    Vibrator vibrator ;

    //AÑADIMOS ENEMIGOS
    ArrayList<Enemigo> enemigos;
    Bitmap[] imagens=new Bitmap[]{
            BitmapFactory.decodeResource(getResources(),R.drawable.enem1c),
            BitmapFactory.decodeResource(getResources(),R.drawable.enem1b),
            BitmapFactory.decodeResource(getResources(),R.drawable.skeleton5),
            BitmapFactory.decodeResource(getResources(),R.drawable.skeleton5),
            BitmapFactory.decodeResource(getResources(),R.drawable.enem1a),

    };

    public MediaPlayer mediaPlayer;
    private AudioManager audioManager;

    public Pantalla pantalla;

    public Juego(Context context) { // Constructor
        super(context);
        this.surfaceHolder = getHolder(); // Se obtiene el holder
        this.surfaceHolder.addCallback(this); // y se indica donde van las funciones callback
        this.context = context; // Obtenemos el contexto

        rectHeroe=new Rect(300,350,600,500);

        hilo = new Hilo(); // Inicializamos el hilo
        setFocusable(true); // Aseguramos que reciba eventos de toque

        //VIBRACIÓN
        vibrator= (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        audioManager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        mediaPlayer= MediaPlayer.create(context,R.raw.duki);
        int v= audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        mediaPlayer.setVolume(v/2,v/2);
    }

    /**
     * Contralamos el cambio de pantallas por constantes finales
     * @param nuevaEscena
     */
    public void cambioEscena(int nuevaEscena){
        if(pantalla.numEscena != nuevaEscena){
            switch (nuevaEscena){
                case Constantes.PMENU:
                    pantalla = new PantallaMenu(nuevaEscena,context,anchoPantalla, altoPantalla);
                    break;
                case Constantes.PAYUDA:
                    pantalla = new PantallaAyuda(nuevaEscena,context, anchoPantalla, altoPantalla);
                    break;
                case Constantes.PJUEGO:
                    pantalla = new PantallaJuego(nuevaEscena, context, anchoPantalla, altoPantalla);
                    break;
                case Constantes.PGAMEOVER:
                    pantalla = new PantallaGameOver(nuevaEscena, context, anchoPantalla, altoPantalla);
                    break;
                case Constantes.PAJUSTES:
                    pantalla = new PantallaAjustes(nuevaEscena, context, anchoPantalla, altoPantalla);
                    break;
                case Constantes.PRECORDS:
                    pantalla = new PantallaRecords(nuevaEscena, context, anchoPantalla, altoPantalla);
                    break;
                case Constantes.PCREDITOS:
                    pantalla = new PantallaCreditos(nuevaEscena, context, anchoPantalla, altoPantalla);
                    break;
            }
        }

    }

    // Callbacks del SurfaceHolder ///////////////////////////////////
    @Override // En cuanto se crea el SurfaceView se lanze el hilo
    public void surfaceCreated(SurfaceHolder holder) {

    }
    // Si hay algún cambio en la superficie de dibujo (normalmente su tamaño) obtenemos el nuevo tamaño


    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        anchoPantalla = width;
        altoPantalla = height;
        pantalla = new PantallaMenu(1, context, anchoPantalla, altoPantalla);

        hilo.setSurfaceSize(width,height);
        hilo.setFuncionando(true);
        if (hilo.getState() == Thread.State.NEW) hilo.start();
        if (hilo.getState() == Thread.State.TERMINATED) {
            hilo=new Hilo();
            hilo.start();
        }
    }
    // Al finalizar el surface, se para el hilo
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        hilo.setFuncionando(false);
        try {
            hilo.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    //Escalar fodo
    public Bitmap escala(int res, int nuevoAncho, int nuevoAlto){
        Bitmap bitmapAux=BitmapFactory.decodeResource(context.getResources(), res);
        return bitmapAux.createScaledBitmap(bitmapAux,nuevoAncho, nuevoAlto, true);
    }

    public Bitmap escalaAnchura(int res, int nuevoAncho) {
        Bitmap bitmapAux = BitmapFactory.decodeResource(context.getResources(), res);
        if (nuevoAncho == bitmapAux.getWidth()) return bitmapAux;
        return bitmapAux.createScaledBitmap(bitmapAux, nuevoAncho, (bitmapAux.getHeight() * nuevoAncho) /
                bitmapAux.getWidth(), true);
    }

    public Bitmap escalaAltura(int res, int nuevoAlto ) {
        Bitmap bitmapAux=BitmapFactory.decodeResource(context.getResources(), res);
        if (nuevoAlto==bitmapAux.getHeight()) return bitmapAux;
        return bitmapAux.createScaledBitmap(bitmapAux, (bitmapAux.getWidth() * nuevoAlto) /
                bitmapAux.getHeight(), nuevoAlto, true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int accion = event.getAction();
        switch (accion){
            case MotionEvent.ACTION_DOWN:
                break;

            case MotionEvent.ACTION_UP:
                int aa = pantalla.onTouch(event);
                cambioEscena(aa);
                break;
        }
        return true;
    }

    // Clase Hilo en la cual se ejecuta el método de dibujo y de física para que se haga en paralelo con la
    // gestión de la interfaz de usuario
    class Hilo extends Thread {
        public Hilo(){
        }
        @Override
        public void run() {
            while (funcionando) {
                Canvas c = null; //Siempre es necesario repintar todo el lienzo
                try {
                    if (!surfaceHolder.getSurface().isValid()) continue; // si la superficie no está preparada repetimos
//c = surfaceHolder.lockCanvas(); // Obtenemos el lienzo con aceleración software
                    c = surfaceHolder.lockHardwareCanvas(); // Obtenemos el lienzo con Aceleración Hw. Desde la API 26
                    synchronized (surfaceHolder) { // La sincronización es necesaria por ser recurso común
                        pantalla.actualizarFisica(); // Movimiento de los elementos
                        pantalla.dibujar(c); // Dibujamos los elementos
                    }
                } finally { // Haya o no excepción, hay que liberar el lienzo
                    if (c != null) {
                        surfaceHolder.unlockCanvasAndPost(c);
                    }
                }
            }
        }
        // Activa o desactiva el funcionamiento del hilo
        void setFuncionando(boolean flag) {
            funcionando = flag;
        }
        // Función llamada si cambia el tamaño del view
        public void setSurfaceSize(int width, int height) {
            synchronized (surfaceHolder) { // Se recomienda realizarlo de forma atómica

                if (bitmapFondo != null) { // Cambiamos el tamaño de la imagen de fondo al tamaño de la pantalla
                    bitmapFondo = Bitmap.createScaledBitmap( bitmapFondo, width, height, true);
                }
                bitmapHeroe = BitmapFactory.decodeResource(context.getResources(), R.drawable.herorun5);
            }
        }


    }
}
