package com.example.secondjuego;

import com.example.secondjuego.Pantallas.Pantalla;

public class Constantes {
    public final static int PMENU=1;
    public final static int PAYUDA=2;
    public final static int PJUEGO=3;
    public final static int PAJUSTES=4;
    public final static int PCREDITOS=5;
    public final static int PRECORDS=6;
    public final static int PGAMEOVER=7;
    public final static int PWIN=8;
}
