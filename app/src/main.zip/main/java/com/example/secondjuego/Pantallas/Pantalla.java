package com.example.secondjuego.Pantallas;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.MotionEvent;

import com.example.secondjuego.R;

public class Pantalla {
    public int numEscena;
    Context context;
    public static int anchoPantalla;
    public static int altoPantalla;
    private Bitmap bitmapFondo; // Imagen de fondo


    public Pantalla(int numEscena, Context context, int anchoPantalla, int altoPantalla) {
        this.numEscena = numEscena;
        this.context = context;
        this.anchoPantalla = anchoPantalla;
        this.altoPantalla = altoPantalla;
    }


    public void dibujar (Canvas c){

    }
    public void actualizarFisica(){

    }
    public int onTouch (MotionEvent event){

        return numEscena;
    }
}
