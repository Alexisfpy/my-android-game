package com.example.secondjuego;

import android.graphics.Bitmap;
import android.graphics.PointF;

public class Fondo {
    //point f no hace falta
    public PointF posicion;
    public Bitmap imagen;
    public Fondo(Bitmap imagen, float x) { // Constructores
        this.imagen = imagen;
        this.posicion = new PointF(x, 0);
    }
    public Fondo(Bitmap imagen) {

        this(imagen, 0);
    }
    public void mover(int velocidad) { // Desplazamiento

        posicion.x += velocidad;
    }

}
