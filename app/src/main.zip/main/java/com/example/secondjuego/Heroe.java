package com.example.secondjuego;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;

import com.example.secondjuego.Pantallas.Pantalla;

import java.util.Random;

public class Heroe {
    public PointF posicion;
    public Bitmap imagen;
    private Random g;
    boolean selection =false;
    public Rect hitboxHereo;
    public Paint paintHeroe;
    public int x1;
    int y2;
    int sx;
    int sy;
    int contador;
    Bitmap bitmaHereo1;
    Bitmap bitmaHereo2;
    Context context;

    Bitmap[] heroe;
    int nuevoFrame;



    public Heroe(Context context, Bitmap imagen, float x, float y, int sx, int sy) {
        this.imagen = imagen;
        this.posicion = new PointF(x, y);
        g = new Random();
        this.paintHeroe = new Paint();
        this.paintHeroe.setColor(Color.WHITE);
        this.paintHeroe.setStyle(Paint.Style.STROKE);
        this.paintHeroe.setStrokeWidth(10);
         x1 = (int)x;
         y2 = (int)y;
         y2=Juego.altoPantalla/2;
         this.sx =sx;
         this.sy=sy;
        hitboxHereo = new Rect(x1,y2,x1+sx,y2+sy);
        this.context=context;
        Bitmap bitmapHeroe1 =escala(R.drawable.ghosthalo1, Juego.anchoPantalla/12-Juego.anchoPantalla/30, Juego.altoPantalla/8);
        Bitmap bitmapHeroe2 =escala(R.drawable.ghosthalo2, Juego.anchoPantalla/12-Juego.anchoPantalla/30, Juego.altoPantalla/8);
        Bitmap bitmapHeroe3 =escala(R.drawable.ghosthalo3, Juego.anchoPantalla/12-Juego.anchoPantalla/30, Juego.altoPantalla/8);
        Bitmap bitmapHeroe4 =escala(R.drawable.ghosthalo4, Juego.anchoPantalla/12-Juego.anchoPantalla/30, Juego.altoPantalla/8);
        heroe = new Bitmap[]{
                bitmapHeroe1,
                bitmapHeroe2,
                bitmapHeroe3,
                bitmapHeroe4,
        };

    }
    public Bitmap escala(int res, int nuevoAncho, int nuevoAlto){
        Bitmap bitmapAux=BitmapFactory.decodeResource(context.getResources(), res);
        return bitmapAux.createScaledBitmap(bitmapAux,nuevoAncho, nuevoAlto, true);
    }

    public void dibujar (Canvas c){
        c.drawBitmap(imagen, x1, y2,null);
        //c.drawRect(hitboxHereo,paintHeroe);
        if (nuevoFrame%15==0){
            sprites();
        }
        nuevoFrame++;
    }

    public void actulizarHitbox(){

        hitboxHereo = new Rect(x1,y2,x1+sx,y2+sy);
    }


    public void actualizarFisica(){
        this.posicion = new PointF(x1, y2);

        new Heroe(context, imagen,(float) x1, (float) y2, sx, sy);
    }
    //movimiento
    public void saltoHeroe(int alto, int ancho, int velocidad){
        if(y2>alto/25){
            y2 = y2-(alto/16);
            actualizarFisica();
            actulizarHitbox();

        }
    }
    public void caidaHeroe(int alto, int ancho, int velocidad ){
        if(y2<alto*3/4){
            y2 = y2 +(alto/16);
            actualizarFisica();
            actulizarHitbox();
        }
    }
    public void sprites(){

        if (contador<heroe.length){
            this.imagen = heroe[contador];
            contador++;

        }else{
            contador=0;
        }

    }

}
