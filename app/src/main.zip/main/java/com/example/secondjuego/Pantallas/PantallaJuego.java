package com.example.secondjuego.Pantallas;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.MotionEvent;

import com.example.secondjuego.Constantes;
import com.example.secondjuego.Enemigo;
import com.example.secondjuego.EnemigoFly;
import com.example.secondjuego.Fondo;
import com.example.secondjuego.Heroe;
import com.example.secondjuego.R;
import com.example.secondjuego.Vida;

import java.util.ArrayList;
import java.util.Timer;

public class PantallaJuego extends Pantalla {
    int numEscena;
    Context context;
    int anchoPantalla;
    int altoPantalla;
    //Heroe
    Heroe heroe;
    Rect rectHeroe;
    Bitmap bitmapHeroeGhost;
    Bitmap bitmapHeroeGhost2;
    MotionEvent event;
    int contadorHereo;

    //Enemigos
    ArrayList<Enemigo> enemigos= new ArrayList<Enemigo>();
    Bitmap bitmapEnemigRun;
    ArrayList<EnemigoFly> enemigosFly = new ArrayList<>();
    Bitmap bitmapEnemig1b;


    //Fondo
    private Bitmap bitmapFondo; // Imagen de fondo
    private Fondo[]fondo = new Fondo[2];
    private boolean esTitulo=true;
    int cont =0;

    //Vida
    Vida vida;
    int vidaGanar;

    //Choque
    int choqueCont=-4;

    //Vibracion
    Vibrator vibrator;

    //Musica
    public static MediaPlayer mediaPlayer;
    public static  AudioManager audioManager;

    public boolean pararJuego;

    //Timer
    Timer timer = new Timer();

    public PantallaJuego(int numEscena, Context context, int anchoPantalla, int altoPantalla) {
        super(numEscena, context, anchoPantalla, altoPantalla);
        this.numEscena = numEscena;
        this.context = context;
        this.anchoPantalla = anchoPantalla;
        this.altoPantalla = altoPantalla;
        this.vidaGanar =10000;
        pararJuego = false;
        //hereo
        bitmapHeroeGhost =escala(R.drawable.ghosthalo1, anchoPantalla/12-anchoPantalla/30, altoPantalla/8);
        bitmapHeroeGhost2 =escala(R.drawable.ghosthalo4, anchoPantalla/12-anchoPantalla/30, altoPantalla/8);

        rectHeroe=new Rect(300,350,600,500);
        heroe = new Heroe(context,bitmapHeroeGhost, anchoPantalla/10, altoPantalla/5,anchoPantalla/12-anchoPantalla/30,altoPantalla/10 );

        //Enemigos
        int parteX=anchoPantalla/20;
        int parteY=altoPantalla/10;

        bitmapEnemig1b =escala(R.drawable.enem1b,anchoPantalla/10,altoPantalla/5);
        bitmapEnemigRun = escala(R.drawable.enem2a,anchoPantalla/10, altoPantalla/5);

        enemigosFly.add(new EnemigoFly(anchoPantalla, parteY, anchoPantalla/10,altoPantalla/6,parteX/10,Color.BLUE,bitmapEnemig1b, context));
        enemigosFly.add(new EnemigoFly(anchoPantalla,parteY*4,anchoPantalla/10,altoPantalla/6,parteX/8,Color.BLACK,bitmapEnemig1b, context));
        enemigos.add(new Enemigo(anchoPantalla,parteY*7,anchoPantalla/10,altoPantalla/5,parteX/15,Color.MAGENTA,bitmapEnemigRun, context));
        enemigos.add(new Enemigo(anchoPantalla,parteY*8,anchoPantalla/10,altoPantalla/5,parteX/12,Color.GRAY,bitmapEnemigRun, context));
        //enemigos.add(new Enemigo(anchoPantalla,parteY*5,anchoPantalla/10,altoPantalla/6,parteX/10,Color.YELLOW,bitmapEnemig1b));

        //Fondo
        bitmapFondo=escalaAltura(R.drawable.city,altoPantalla);
        fondo[0] = new Fondo(bitmapFondo);
        fondo[1] = new Fondo(bitmapFondo,fondo[0].imagen.getWidth());

        //Vida
        vida = new Vida(100,500, anchoPantalla, altoPantalla);

        //Vibración
        vibrator= (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);

        //Musica
        audioManager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        mediaPlayer= MediaPlayer.create(context,R.raw.duki);
        int v= audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        if (!mediaPlayer.isPlaying()){
            mediaPlayer.setVolume(v/2,v/2);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }
    }

    public Bitmap escala(int res, int nuevoAncho, int nuevoAlto){
        Bitmap bitmapAux=BitmapFactory.decodeResource(context.getResources(), res);
        return bitmapAux.createScaledBitmap(bitmapAux,nuevoAncho, nuevoAlto, true);
    }
    public Bitmap escalaAltura(int res, int nuevoAlto ) {
        Bitmap bitmapAux=BitmapFactory.decodeResource(context.getResources(), res);
        if (nuevoAlto==bitmapAux.getHeight()) return bitmapAux;
        return bitmapAux.createScaledBitmap(bitmapAux, (bitmapAux.getWidth() * nuevoAlto) /
                bitmapAux.getHeight(), nuevoAlto, true);
    }

    public void dibujar(Canvas c) {
        contadorHereo++;
        try {
            if (esTitulo){
                c.drawBitmap(bitmapFondo, 0, 0, null); // Dibujamos el fondo
                esTitulo=false;
            }
            else {
                c.drawBitmap(fondo[0].imagen, fondo[0].posicion.x, 0, null);
                c.drawBitmap(fondo[1].imagen, fondo[1].posicion.x, 0, null);
                cont++;
            }

            for(Enemigo e:enemigos){
                e.mover();
                e.dibujar(c);
            }
            for(EnemigoFly eFly:enemigosFly){
                eFly.mover();
                eFly.dibujar(c);
            }
            vida.dibujar(c);
            heroe.dibujar(c);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actualizarFisica(){
        if (!pararJuego){
            vida.progeso++;

            fondo[0].mover(-5);
            fondo[1].mover(-5);
// Comprobamos que se sobrepase la pantalla y reiniciamos
            if (fondo[0].posicion.x+fondo[0].imagen.getWidth()<0 ) {
                fondo[0].posicion.x = fondo[1].posicion.x + fondo[1].imagen.getWidth();
            }

            if (fondo[1].posicion.x+fondo[1].imagen.getWidth()<0 ) {
                fondo[1].posicion.x = fondo[0].posicion.x + fondo[0].imagen.getWidth();
            }

            heroe.actualizarFisica();
            for(EnemigoFly eFly:enemigosFly) {


                for (Enemigo e : enemigos) {
                    if (e.hitbox.intersect(heroe.hitboxHereo) || eFly.hitbox.intersect(heroe.hitboxHereo)) {
                        Log.i("colision", "choque: " + choqueCont);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                        } else {
                            vibrator.vibrate(300);
                        }
                        Enemigo.boolColision = true;
                        EnemigoFly.boolColision = true;
                        vida.numVidas--;
                        if (vida.numVidas == 0 || vida.win == Vida.progeso) {
                            mediaPlayer.stop();
                            pararJuego = true;
                        }
                        //funcionando = false;
                    } else {
                        Enemigo.boolColision = false;
                        EnemigoFly.boolColision = false;
                    }
                }
            }
        }

    }

    public int onTouch (MotionEvent event){
        //int accion = event.getAction();
        if(!pararJuego){
            switch (event.getAction()){
                case MotionEvent.ACTION_UP:
                    if (event.getX()<anchoPantalla/2){
                        heroe.saltoHeroe(altoPantalla,anchoPantalla,5);
                    }else{
                        heroe.caidaHeroe(altoPantalla, anchoPantalla, 5);
                    }
                    break;
            }
        }else{
            return Constantes.PGAMEOVER;
        }
        return 18;
    }

}
