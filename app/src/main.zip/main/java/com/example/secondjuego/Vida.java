package com.example.secondjuego;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Vida {
    public int numVidas;
    int anchoPantalla;
    int altoPantalla;
    public int win;
    public static int progeso;
    Paint p;
    public Vida (int numVidas,int win, int anchoPantalla, int altoPantalla){
        this.numVidas = numVidas;
        this.win=win;
        this.anchoPantalla = anchoPantalla;
        this.altoPantalla = altoPantalla;
        this.progeso =0;
        p= new Paint();
        p.setColor(Color.WHITE);
        p.setTextSize(altoPantalla/20);
        p.setTextAlign(Paint.Align.CENTER);
    }
    public void dibujar (Canvas c){
        c.drawText("Vida "+String.valueOf(numVidas), anchoPantalla*8/10, altoPantalla/8,p);
        c.drawText(String.valueOf(progeso)+" m", anchoPantalla/3, altoPantalla/8,p);
    }

}
