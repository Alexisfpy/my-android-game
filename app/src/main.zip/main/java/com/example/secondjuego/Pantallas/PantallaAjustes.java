package com.example.secondjuego.Pantallas;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;

import com.example.secondjuego.Constantes;
import com.example.secondjuego.R;

public class PantallaAjustes extends Pantalla{
    int numEscena;
    Context context;
    int anchoPantalla;
    int altoPantalla;
    Paint p;
    Bitmap bitmapMenu;
    Bitmap bitmapBack;
    Rect gameOver;

    public PantallaAjustes(int numEscena, Context context, int anchoPantalla, int altoPantalla) {
        super(numEscena, context, anchoPantalla, altoPantalla);
        this.numEscena = numEscena;
        this.context = context;
        this.anchoPantalla = anchoPantalla;
        this.altoPantalla = altoPantalla;
        p= new Paint();
        p.setColor(Color.BLUE);
        p.setTextSize(altoPantalla/4);
        p.setTextAlign(Paint.Align.CENTER);
        bitmapMenu=escala(R.drawable.fondomenu2,anchoPantalla,altoPantalla);
        bitmapBack = BitmapFactory.decodeResource(context.getResources(),R.drawable.backdef);
        gameOver = new Rect(0,altoPantalla-altoPantalla/6,anchoPantalla/5, altoPantalla);
    }
    public Bitmap escala(int res, int nuevoAncho, int nuevoAlto){
        Bitmap bitmapAux= BitmapFactory.decodeResource(context.getResources(), res);
        return bitmapAux.createScaledBitmap(bitmapAux,nuevoAncho, nuevoAlto, true);
    }

    @Override
    public void dibujar(Canvas c) {
        c.drawBitmap(bitmapMenu, 0, 0, null);
        c.drawText("AJUSTES", anchoPantalla/2,altoPantalla/3,p);
        c.drawBitmap(bitmapBack,0,altoPantalla-altoPantalla/6,null);

    }

    public int onTouch (MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_UP) {
            int x = (int) event.getX();
            int y = (int) event.getY();
            if (gameOver.contains(x, y)) {
                if (PantallaMenu.mPMenu !=null){
                    PantallaMenu.mPMenu.stop();
                }
                return Constantes.PMENU;
            }
        }
        return 18;
    }
}
