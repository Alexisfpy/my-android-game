package com.example.secondjuego.Pantallas;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.MotionEvent;

import com.example.secondjuego.Constantes;
import com.example.secondjuego.Pantallas.Pantalla;
import com.example.secondjuego.R;

public class PantallaMenu extends Pantalla {
    int numEscena;
    Context context;
    int anchoPantalla;
    int altoPantalla;
    Paint p;
    Paint pBack;
    Rect ayuda, juego, opciones, creditos, records;
    Bitmap bitmapMenu;
    Bitmap bitmapHelp;
    Bitmap bitmapSettings;
    Bitmap bitmapStart;
    Bitmap bitmapRecords;
    Bitmap bitmapCredits;

    public static MediaPlayer mPMenu;
    public static AudioManager audioMenu;

    public PantallaMenu(int numEscena, Context context, int anchoPantalla, int altoPantalla) {
        super(numEscena, context, anchoPantalla, altoPantalla);
        this.numEscena = numEscena;
        this.context = context;
        this.anchoPantalla = anchoPantalla;
        this.altoPantalla = altoPantalla;
        //Fondo e imagenes
        bitmapMenu=escala(R.drawable.fondomenu2,anchoPantalla,altoPantalla);
        //bitmapHelp = BitmapFactory.decodeResource(context.getResources(),R.drawable.help);
        bitmapHelp = escala(R.drawable.help,anchoPantalla/12, altoPantalla/9);
        bitmapSettings= escala(R.drawable.settings,anchoPantalla/13, altoPantalla/9);
        bitmapStart= escala(R.drawable.start,anchoPantalla/10, altoPantalla/3);
        bitmapRecords= escala(R.drawable.records,anchoPantalla/10, altoPantalla/7);
        bitmapCredits = escala(R.drawable.creditsmod,anchoPantalla/8, altoPantalla/8);

        p= new Paint();
        p.setColor(Color.BLUE);
        p.setTextSize(altoPantalla/4);
        p.setTextAlign(Paint.Align.CENTER);

        pBack= new Paint();
        pBack.setColor(Color.GREEN);
        pBack.setTextSize(altoPantalla/4);
        pBack.setTextAlign(Paint.Align.CENTER);

        juego = new Rect(anchoPantalla-anchoPantalla/8, altoPantalla-altoPantalla/4,anchoPantalla,altoPantalla-altoPantalla/17);
        opciones = new Rect(anchoPantalla/22,0+altoPantalla/20,anchoPantalla/8, altoPantalla/8);
        ayuda = new Rect(anchoPantalla/6, 0+altoPantalla/20, altoPantalla/2, altoPantalla/8+altoPantalla/20);
        creditos = new Rect(anchoPantalla/3, 0+altoPantalla/20, anchoPantalla/2, altoPantalla/9+altoPantalla/20);
        records = new Rect(anchoPantalla-anchoPantalla/8,0+altoPantalla/20, anchoPantalla, altoPantalla/8+altoPantalla/20);
        //musica
        audioMenu=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        mPMenu= MediaPlayer.create(context,R.raw.backtothehood);
        int v= audioMenu.getStreamVolume(AudioManager.STREAM_MUSIC);

        if (!mPMenu.isPlaying()){
            mPMenu.setVolume(v/2, v/2);
            mPMenu.start();
            mPMenu.setLooping(true);
        }

    }

    public Bitmap escalaAltura(int res, int nuevoAlto ) {
        Bitmap bitmapAux= BitmapFactory.decodeResource(context.getResources(), res);
        if (nuevoAlto==bitmapAux.getHeight()) return bitmapAux;
        return bitmapAux.createScaledBitmap(bitmapAux, (bitmapAux.getWidth() * nuevoAlto) /
                bitmapAux.getHeight(), nuevoAlto, true);
    }
    public Bitmap escala(int res, int nuevoAncho, int nuevoAlto){
        Bitmap bitmapAux=BitmapFactory.decodeResource(context.getResources(), res);
        return bitmapAux.createScaledBitmap(bitmapAux,nuevoAncho, nuevoAlto, true);
    }

    /**
     * Dibujamos tanto el fondo como los iconos de ajustes, ayuda, records y start de partida
     * @param c
     */
    public void dibujar (Canvas c){
        c.drawBitmap(bitmapMenu, 0, 0, null);
        //c.drawText("Soy menú", anchoPantalla/2,altoPantalla/3,p);
        //c.drawRect(juego, p);
        //c.drawRect(ayuda, p);
        //c.drawRect(opciones,pBack);
        //c.drawRect(records,p);
        //c.drawRect(creditos,pBack);

        c.drawBitmap(bitmapSettings,anchoPantalla/22,0+altoPantalla/20,null );
        c.drawBitmap(bitmapHelp,anchoPantalla/6,0+altoPantalla/20,null);
        c.drawBitmap(bitmapStart,anchoPantalla-anchoPantalla/8,altoPantalla-altoPantalla/3, null);
        c.drawBitmap(bitmapRecords,anchoPantalla-anchoPantalla/8,0+altoPantalla/20,null );
        c.drawBitmap(bitmapCredits,anchoPantalla/3,0+altoPantalla/25,null);



    }
    public void actualizarFisica(){

    }

    /**
     * Gestiona el cambio de pantallas en el menú: ajustes, ayuda, record, créditos y start
     * @param event
     * @return
     */
    public int onTouch (MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_UP){
            int x = (int) event.getX();
            int y = (int) event.getY();
            if(juego.contains(x,y)){
                mPMenu.stop();
                return  Constantes.PJUEGO;
            }else if (ayuda.contains(x,y)){
                return  Constantes.PAYUDA;
            } else if (opciones.contains(x,y)){
                return Constantes.PAJUSTES;
            } else if (records.contains(x,y)){
                return Constantes.PRECORDS;
            } else if (creditos.contains(x,y)){
                return  Constantes.PCREDITOS;
            }

        }
        return numEscena;
    }
}
