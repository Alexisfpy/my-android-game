package com.example.secondjuego.Pantallas;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;

import com.example.secondjuego.Constantes;
import com.example.secondjuego.R;
import com.example.secondjuego.Vida;

public class PantallaGameOver extends  Pantalla{
    int numEscena;
    Context context;
    int anchoPantalla;
    int altoPantalla;
    //
    Bitmap bitmapFondo;
    Bitmap bitmapGOver;
    Bitmap bitmapBack;
    Paint pGOver;
    Rect gameOver;
    public PantallaGameOver(int numEscena, Context context, int anchoPantalla, int altoPantalla) {
        super(numEscena, context, anchoPantalla, altoPantalla);
        this.numEscena = numEscena;
        this.context = context;
        this.anchoPantalla = anchoPantalla;
        this.altoPantalla = altoPantalla;

        //Fondo
        bitmapFondo=escala(R.drawable.fondo2,anchoPantalla, altoPantalla);
        bitmapGOver = BitmapFactory.decodeResource(context.getResources(),R.drawable.gameover);
        bitmapBack = BitmapFactory.decodeResource(context.getResources(),R.drawable.backdef);
        pGOver= new Paint();
        pGOver= new Paint();
        pGOver.setColor(Color.WHITE);
        pGOver.setTextSize(altoPantalla/5);
        pGOver.setTextAlign(Paint.Align.CENTER);
        gameOver = new Rect(0,altoPantalla-altoPantalla/6,anchoPantalla/5, altoPantalla);


    }
    public Bitmap escalaAltura(int res, int nuevoAlto ) {
        Bitmap bitmapAux= BitmapFactory.decodeResource(context.getResources(), res);
        if (nuevoAlto==bitmapAux.getHeight()) return bitmapAux;
        return bitmapAux.createScaledBitmap(bitmapAux, (bitmapAux.getWidth() * nuevoAlto) /
                bitmapAux.getHeight(), nuevoAlto, true);
    }
    public Bitmap escala(int res, int nuevoAncho, int nuevoAlto){
        Bitmap bitmapAux=BitmapFactory.decodeResource(context.getResources(), res);
        return bitmapAux.createScaledBitmap(bitmapAux,nuevoAncho, nuevoAlto, true);
    }

    public Bitmap escalaAnchura(int res, int nuevoAncho) {
        Bitmap bitmapAux = BitmapFactory.decodeResource(context.getResources(), res);
        if (nuevoAncho == bitmapAux.getWidth()) return bitmapAux;
        return bitmapAux.createScaledBitmap(bitmapAux, nuevoAncho, (bitmapAux.getHeight() * nuevoAncho) /
                bitmapAux.getWidth(), true);
    }

    @Override
    public void dibujar(Canvas c) {
        //c.drawColor(Color.MAGENTA);
        c.drawBitmap(bitmapFondo,0,0,null);
        c.drawBitmap(bitmapGOver,anchoPantalla/3, altoPantalla/4,null);
        c.drawBitmap(bitmapBack,0,altoPantalla-altoPantalla/6,null);
        c.drawText(String.valueOf(Vida.progeso), anchoPantalla/2,altoPantalla-altoPantalla/4,pGOver);
        //c.drawRect(gameOver, pGOver);
    }

    public int onTouch (MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_UP) {
            int x = (int) event.getX();
            int y = (int) event.getY();
            if (gameOver.contains(x, y)) {
                guardarPreferencias();
                return Constantes.PMENU;
            }
        }
    return 18;
    }


    public void guardarPreferencias(){
        SharedPreferences preferences= context.getSharedPreferences("credenciales",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        long progresoRecord = preferences.getInt("Record",0);
        if(Long.valueOf(Vida.progeso)>=progresoRecord){
            editor.putInt("Record", Vida.progeso);
        }
        editor.commit();
    }


}
