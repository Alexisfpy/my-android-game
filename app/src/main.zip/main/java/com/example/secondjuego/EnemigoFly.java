package com.example.secondjuego;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class EnemigoFly {
    int x, y;
    public Rect hitbox;
    int color;
    int velocidadx;
    Paint paint;
    int sx,sy;
    Context context;
    Bitmap imagen;
    public  int aceleracionEnemigo;

    public static boolean boolColision=false;

    Bitmap[] imagenesRun;

    int cont=0;

    int nuevoFrame=0;


    public EnemigoFly(int x, int y, int sx, int sy, int velocidadx, int color, Bitmap imagen, Context context) {
        this.y = y;
        this.color=color;
        this.velocidadx=velocidadx;
        this.sx=sx;
        this.sy=sy;
        this.imagen=imagen;
        this.context=context;

        this.paint=new Paint();
        this.paint.setColor(color);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(10);
        //CON -20 MENOR TAMAÑO DE LA RECT HITBOX
        hitbox=new Rect(x+Juego.anchoPantalla/17,y+Juego.altoPantalla/20,x+sx-Juego.anchoPantalla/17,y+sy-Juego.altoPantalla/20);
        //hitbox=new Rect(x+20,y+25,x+sx-20,y+sy-15);
        aceleracionEnemigo=0;
        Bitmap bitmapEnemigFly1 = escala(R.drawable.enem1b,Juego.anchoPantalla/10, Juego.altoPantalla/5);
        Bitmap bitmapEnemigFly2 = escala(R.drawable.enem2b,Juego.anchoPantalla/10, Juego.altoPantalla/5);
        Bitmap bitmapEnemigFly3 = escala(R.drawable.enem3b,Juego.anchoPantalla/10, Juego.altoPantalla/5);
        Bitmap bitmapEnemigFly4 = escala(R.drawable.enem4b,Juego.anchoPantalla/10, Juego.altoPantalla/5);
        Bitmap bitmapEnemigFly5 = escala(R.drawable.enem5b,Juego.anchoPantalla/10, Juego.altoPantalla/5);
        Bitmap bitmapEnemigFly6 = escala(R.drawable.enem6b,Juego.anchoPantalla/10, Juego.altoPantalla/5);



        imagenesRun = new Bitmap[]{
                bitmapEnemigFly1,
                bitmapEnemigFly2,
                bitmapEnemigFly3,
                bitmapEnemigFly4,
                bitmapEnemigFly5,
                bitmapEnemigFly6,

        };
    }
    public Bitmap escala(int res, int nuevoAncho, int nuevoAlto){
        Bitmap bitmapAux= BitmapFactory.decodeResource(context.getResources(), res);
        return bitmapAux.createScaledBitmap(bitmapAux,nuevoAncho, nuevoAlto, true);
    }

    public  void dibujar(Canvas c){
        c.drawBitmap(imagen,x,y,null);
        //c.drawRect(hitbox,paint);
        if(nuevoFrame%15==0){
            sprites();
        }
        nuevoFrame++;
    }

    public void actualizaHitbox(){
        hitbox=new Rect(x+20,y+25,x+sx-20,y+sy-15);
    }

    /**
     * Gestionamos el movimiento del emenigo, con una posición y aleatoria manteniendo los rangos
     * de la pantalla
     */
    public void mover(){
        this.x -= velocidadx+aceleracionEnemigo();
        if (x<0-sx){
            x=Juego.anchoPantalla;
            y=(int)(Math.random()*(Juego.altoPantalla-sy));
        }
        actualizaHitbox();
    }

    /**
     * Cade cierto progreso que lleve el jugador en el juego, aumenta la velocidad de movimiento de los enemigos
     * @return
     */
    public int aceleracionEnemigo(){
        if (Vida.progeso%500==0){
            aceleracionEnemigo++;
        }
        return aceleracionEnemigo;
    }
    public void sprites(){
        if (cont<imagenesRun.length){
            this.imagen = imagenesRun[cont];
            cont++;

        }else{
            cont=0;
        }

    }

}
